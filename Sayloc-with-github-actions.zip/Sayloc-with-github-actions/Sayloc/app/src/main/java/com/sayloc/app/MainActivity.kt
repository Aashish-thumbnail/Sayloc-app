package com.sayloc.app

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.LifecycleResumeEffect

private val Navy = Color(0xFF070522)
private val Violet = Color(0xFF8B5CF6)
private val Electric = Color(0xFF3B82F6)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { SaylocApp() }
    }
}

@Composable
fun Glass(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(28.dp),
    content: @Composable BoxScope.() -> Unit
) {
    Box(
        modifier
            .clip(shape)
            .background(Brush.verticalGradient(listOf(Color.White.copy(0.16f), Color.White.copy(0.05f))))
            .border(1.dp, Brush.linearGradient(listOf(Color.White.copy(0.55f), Color.White.copy(0.08f))), shape),
        content = content
    )
}

@Composable
fun SaylocApp() {
    var tab by remember { mutableIntStateOf(0) }
    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF1B1066), Navy, Color(0xFF020214))))
            .systemBarsPadding()
    ) {
        Column(Modifier.fillMaxSize().padding(bottom = 96.dp)) {
            when (tab) {
                0 -> HomeScreen()
                1 -> Placeholder("Commands", "Yahan aap RIYA, AASHU jaise apne voice commands set karenge.")
                else -> Placeholder("Settings", "Voice, battery aur look ki settings agle step mein aayengi.")
            }
        }
        NavPill(tab, { tab = it }, Modifier.align(Alignment.BottomCenter).padding(16.dp))
    }
}

@Composable
fun HomeScreen() {
    val ctx = LocalContext.current
    val haptic = LocalHapticFeedback.current
    val dpm = remember { ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager }
    val admin = remember { ComponentName(ctx, LockAdminReceiver::class.java) }
    var isAdmin by remember { mutableStateOf(dpm.isAdminActive(admin)) }
    LifecycleResumeEffect(Unit) {
        isAdmin = dpm.isAdminActive(admin)
        onPauseOrDispose { }
    }

    val pulse = rememberInfiniteTransition(label = "pulse")
    val breathe by pulse.animateFloat(
        1f, 1.05f,
        infiniteRepeatable(tween(2200, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "b"
    )
    val ring by pulse.animateFloat(
        1f, 1.5f, infiniteRepeatable(tween(2600, easing = LinearOutSlowInEasing)), label = "r"
    )
    val ringAlpha by pulse.animateFloat(
        0.45f, 0f, infiniteRepeatable(tween(2600, easing = LinearOutSlowInEasing)), label = "a"
    )

    Column(
        Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(16.dp))
        Text("Sayloc", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.SemiBold)
        Text("Say it. Lock it.", color = Color.White.copy(0.6f), fontSize = 14.sp)
        Spacer(Modifier.weight(1f))

        Box(Modifier.size(240.dp), contentAlignment = Alignment.Center) {
            Box(
                Modifier.size(200.dp).scale(ring).alpha(ringAlpha)
                    .border(2.dp, Brush.linearGradient(listOf(Violet, Electric)), CircleShape)
            )
            Image(
                painterResource(R.drawable.sayloc_logo), "Sayloc",
                Modifier.size(200.dp).scale(breathe).clip(RoundedCornerShape(44.dp))
            )
        }

        Spacer(Modifier.weight(1f))

        Glass(Modifier.fillMaxWidth()) {
            Text(
                if (isAdmin) "Ready. Lock permission is on." else "Lock permission is off. Turn it on to lock with Sayloc.",
                color = Color.White.copy(0.85f), fontSize = 14.sp, textAlign = TextAlign.Center,
                modifier = Modifier.padding(18.dp).fillMaxWidth()
            )
        }
        Spacer(Modifier.height(16.dp))

        Glass(
            Modifier.fillMaxWidth().height(60.dp).clickable {
                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                if (isAdmin) {
                    dpm.lockNow()
                } else {
                    ctx.startActivity(
                        Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                            .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, admin)
                            .putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Sayloc needs this permission only to lock your screen.")
                    )
                }
            },
            shape = RoundedCornerShape(30.dp)
        ) {
            Box(
                Modifier.matchParentSize()
                    .background(Brush.horizontalGradient(listOf(Violet.copy(0.85f), Electric.copy(0.85f)))),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    if (isAdmin) "Lock now" else "Turn on lock permission",
                    color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}

@Composable
fun Placeholder(title: String, body: String) {
    Column(Modifier.fillMaxSize().padding(32.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Glass(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(title, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                Text(body, color = Color.White.copy(0.7f), fontSize = 14.sp, textAlign = TextAlign.Center)
            }
        }
    }
}

@Composable
fun NavPill(selected: Int, onSelect: (Int) -> Unit, modifier: Modifier = Modifier) {
    val items = listOf("Home", "Commands", "Settings")
    Glass(modifier.fillMaxWidth().height(64.dp), RoundedCornerShape(32.dp)) {
        Row(Modifier.fillMaxSize().padding(6.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
            items.forEachIndexed { i, label ->
                val on = i == selected
                Box(
                    Modifier.weight(1f).fillMaxHeight()
                        .clip(RoundedCornerShape(26.dp))
                        .background(if (on) Brush.horizontalGradient(listOf(Violet.copy(0.75f), Electric.copy(0.75f))) else Brush.horizontalGradient(listOf(Color.Transparent, Color.Transparent)))
                        .clickable { onSelect(i) },
                    contentAlignment = Alignment.Center
                ) {
                    Text(label, color = Color.White.copy(if (on) 1f else 0.65f), fontSize = 14.sp, fontWeight = if (on) FontWeight.SemiBold else FontWeight.Normal)
                }
            }
        }
    }
}
